﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class ConsumeController : Controller
    {
        HttpClient hc = new HttpClient();
        // GET: Consume
        public ActionResult Index()
        {
           

            return View();
        }

       public ActionResult Display() 
       {
             List<Client> list = new List<Client>();
             hc.BaseAddress = new Uri("https://localhost:44394/api/WebApi/GetData");
             var consume = hc.GetAsync("GetData");
             consume.Wait();
             var test = consume.Result;


             if (test.IsSuccessStatusCode)
             {
                 var display = test.Content.ReadAsAsync<List<Client>>();
                 list = display.Result;
             }
             return View(list);
         }

        [HttpGet]
        public ActionResult SendData()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SendData(Client data)
        {
            hc.BaseAddress = new Uri("https://localhost:44394/api/WebApi/Insert");
            var consume = hc.PostAsJsonAsync("Insert",data);
            consume.Wait();
            var test = consume.Result;
            if(test.IsSuccessStatusCode)
            {
               return RedirectToAction("Index", "Home");
            }
            else
            {
                return HttpNotFound();
            }

            return View(data);
        }

        public ActionResult Deletedata(int id)
        {
            Client data = new Client();
            hc.BaseAddress = new Uri("https://localhost:44394/api/WebApi/Delete");
            var consume = hc.DeleteAsync("Delete?id="+id.ToString());
            consume.Wait();
            var test = consume.Result;
            if(test.IsSuccessStatusCode)
            {
                return RedirectToAction("Display");

            }
            return View();

        }


    }
    

}