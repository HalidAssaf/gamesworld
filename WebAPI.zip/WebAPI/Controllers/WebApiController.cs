﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class WebApiController : ApiController
    {
        WorldGameEntities db = new WorldGameEntities();     

        [System.Web.Http.HttpGet]
        public IHttpActionResult GetData()
        {
          
            List<Client> list = db.Clients.ToList();
            return Ok(list);         
        }


        [System.Web.Http.HttpPost]
        public IHttpActionResult Insert(Client client)
        {

         db.Clients.Add(client);
            db.SaveChanges();
            return Ok();

        }   

        [System.Web.Http.HttpDelete]
        public IHttpActionResult Delete(int id)
        {
            Client data = db.Clients.Where(x => x.Client_ID == id).SingleOrDefault();
            db.Clients.Remove(data);
            db.SaveChanges();
            return Ok();
        }

    }
}
