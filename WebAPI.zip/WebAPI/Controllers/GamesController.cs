﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class GamesController : Controller
    {
        HttpClient game = new HttpClient();
        // GET: Games
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult ListGame()
        {
            List<Game> list = new List<Game>();
            game.BaseAddress = new Uri("https://localhost:44394/api/GameApi/GetGame");
            var consume = game.GetAsync("GetData");
            consume.Wait();
            var test = consume.Result;


            if (test.IsSuccessStatusCode)
            {
                var display = test.Content.ReadAsAsync<List<Game>>();
                list = display.Result;
            }
            return View(list);
        }

        [HttpGet]
        public ActionResult SendGame()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SendGame(Game games)
        {
            game.BaseAddress = new Uri("https://localhost:44394/api/GameApi/AddGame");
            var consume = game.PostAsJsonAsync("Insert", games);
            consume.Wait();
            var test = consume.Result;
            if (test.IsSuccessStatusCode)
            {

            }
            else
            {
                return HttpNotFound();
            }

            return View(games);
        }


        public ActionResult DeleteGame(int id)
        {
            Game data = new Game();
            game.BaseAddress = new Uri("https://localhost:44394/api/GameApi/DeleteGame");
            var consume = game.DeleteAsync("Delete?id=" + id.ToString());
            consume.Wait();
            var test = consume.Result;
            if (test.IsSuccessStatusCode)
            {
                return RedirectToAction("ListGame");

            }
            return View();

        }


    }
}