﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Net.Http;
using System.Net;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class GameApiController : ApiController
    {
        WorldGameEntities db= new WorldGameEntities();
       

        [System.Web.Http.HttpGet]
        public IHttpActionResult GetGame()
        {
            List<Game> gamelist = db.Games.ToList();
            return Ok(gamelist);































































        }


        [System.Web.Http.HttpPost]
        public IHttpActionResult AddGame(Game game)
        {
            db.Games.Add(game);
            db.SaveChanges();
            return Ok();
        }

        [System.Web.Http.HttpDelete]
        public IHttpActionResult DeleteGame(int id)
        {
            Game data = db.Games.Where(x => x.GameID == id).SingleOrDefault();
            db.Games.Remove(data);
            db.SaveChanges();
            return Ok();
        }



    }
}